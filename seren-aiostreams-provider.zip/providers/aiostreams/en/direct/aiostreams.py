# -*- coding: utf-8 -*-
from providerModules.aiostreams.core import AIOStreamsScraper


class sources(object):
    def __init__(self):
        self.scraper = AIOStreamsScraper()

    def movie(self, title, year, imdb=None, simple_info=None, info=None, **kwargs):
        meta = (info or {}).get("info", {})
        return self.scraper.movie(imdb or meta.get("imdb_id"), meta.get("tmdb_id"))

    def episode(self, simple_info, info, **kwargs):
        meta = (info or {}).get("info", {})
        imdb = meta.get("tvshow.imdb_id")
        tmdb = meta.get("tvshow.tmdb_id") or meta.get("tmdb_show_id")
        season = (simple_info or {}).get("season_number") or meta.get("season")
        episode = (simple_info or {}).get("episode_number") or meta.get("episode")
        return self.scraper.episode(imdb, tmdb, season, episode)
