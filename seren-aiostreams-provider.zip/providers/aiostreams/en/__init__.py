# -*- coding: utf-8 -*-
def get_direct():
    return ["aiostreams"]


def get_torrent():
    return []


def get_hosters():
    return []


def get_adaptive():
    return []
