# -*- coding: utf-8 -*-
"""
AIOStreams scraper for Seren.

Fetches streams from your own AIOStreams instance (via the manifest URL)
and hands them to Seren as 'direct' sources. AIOStreams does the searching,
filtering and sorting; Seren only plays the link.

Security note: the manifest URL (and the stream URLs AIOStreams returns)
contain your encrypted config with debrid credentials. Never write them to
the log, and never put them in an error message.
"""
import hashlib
import json
import os
import re
import time

try:  # Python 3
    from urllib.parse import quote, urlencode
except ImportError:  # pragma: no cover
    from urllib import quote, urlencode

import requests

PACKAGE_NAME = "aiostreams"
VERSION = "1.1.1"
USER_AGENT = "AIOStreams-Seren/1.1.1"  # 'AIO...' => AIOStreams adds streamData
TEST_IMDB_ID = "tt0111161"  # used by the "Test connection" button

SKIP_TYPES = {"error", "statistic", "info", "external", "youtube", "p2p", "live"}

VISUAL_MAP = {
    "DV": {"DV"},
    "DV ONLY": {"DV"},
    "HDR+DV": {"DV", "HDR"},
    "HDR": {"HDR"},
    "HDR10": {"HDR"},
    "HDR10+": {"HDR"},
    "HDR ONLY": {"HDR"},
    "HLG": {"HDR"},
    "SDR": {"SDR"},
    "3D": {"3D"},
}
AUDIO_MAP = {
    "ATMOS": "ATMOS",
    "TRUEHD": "TRUEHD",
    "DTS:X": "DTS-X",
    "DTS-HD MA": "DTS-HDMA",
    "DTS-HD": "DTS-HD",
    "DTS-ES": "DTS",
    "DTS": "DTS",
    "DD+": "DD+",
    "DD": "DD",
    "AAC": "AAC",
    "OPUS": "OPUS",
}
ENCODE_MAP = {"HEVC": "HEVC", "AVC": "AVC", "AV1": "AV1", "XVID": "XVID", "DIVX": "DIVX"}
QUALITY_MAP = {
    "BLURAY REMUX": {"REMUX", "BLURAY"},
    "BLURAY": {"BLURAY"},
    "WEB-DL": {"WEB"},
    "WEBRIP": {"WEB"},
    "HDTV": {"HDTV"},
    "CAM": {"CAM"},
    "TS": {"CAM"},
    "TC": {"CAM"},
    "SCR": {"SCR"},
    "DVDRIP": {"DVDRIP"},
    "HDRIP": {"HD-RIP"},
}
RESOLUTION_MAP = {"2160p": "4K", "1440p": "1080p", "1080p": "1080p", "720p": "720p"}

# Short codes for the language tag in the title (AIOStreams language names)
LANGUAGE_CODES = {
    "dutch": "NL",
    "english": "EN",
    "german": "DE",
    "french": "FR",
    "spanish": "ES",
    "italian": "IT",
    "portuguese": "PT",
    "japanese": "JA",
    "korean": "KO",
    "multi": "MULTI",
}
FEL_RE = re.compile(r"(?:^|[ ._\-\[(])FEL(?=$|[ ._\-\])])", re.I)
P7_RE = re.compile(r"(?:^|[ ._\-\[(])(?:DV[ ._-]?)?P7(?=$|[ ._\-\])])", re.I)
IMAX_RE = re.compile(r"(?:^|[ ._\-\[(])IMAX(?=$|[ ._\-\])])", re.I)


# --------------------------------------------------------------------------
# Small helpers around Seren / Kodi (safe to import outside Kodi for tests)
# --------------------------------------------------------------------------
def _setting(name, default):
    try:
        from resources.lib.common import provider_tools

        value = provider_tools.get_setting(PACKAGE_NAME, name)
        return default if value is None else value
    except Exception:
        return default


def _log(msg, level="info"):
    try:
        from resources.lib.modules.globals import g

        g.log("[AIOStreams] {}".format(msg), level)
    except Exception:
        pass


def _safe_error(e):
    """Describe an exception WITHOUT its message (which may contain the URL)."""
    status = getattr(getattr(e, "response", None), "status_code", None)
    return "{}{}".format(type(e).__name__, " (HTTP {})".format(status) if status else "")


def _int_setting(name, default, minimum=0):
    try:
        return max(minimum, int(_setting(name, default)))
    except (TypeError, ValueError):
        return default


def _cache_dir():
    try:
        import xbmcvfs

        base = xbmcvfs.translatePath("special://temp/")
    except Exception:
        base = os.environ.get("AIOSTREAMS_SEREN_CACHE", "/tmp")
    path = os.path.join(base, "aiostreams_seren_cache")
    if not os.path.isdir(path):
        try:
            os.makedirs(path)
        except OSError:
            return None
    return path


def base_url_from_manifest(url):
    """Turns a (manifest) URL into the add-on's base URL."""
    url = (url or "").strip()
    if not url:
        return ""
    if url.startswith("stremio://"):
        url = "https://" + url[len("stremio://"):]
    if not re.match(r"^https?://", url, re.I):
        url = "https://" + url
    url = url.split("?")[0].rstrip("/")
    if url.endswith("/manifest.json"):
        url = url[: -len("/manifest.json")]
    elif url.endswith("/configure"):
        url = url[: -len("/configure")]
    return url.rstrip("/")


def _fallback_info(title):
    try:
        from resources.lib.common import source_utils

        return set(source_utils.get_info(title))
    except Exception:
        return set()


def _fallback_quality(title):
    try:
        from resources.lib.common import source_utils

        return source_utils.get_quality(title)
    except Exception:
        t = title.lower()
        if "2160" in t or "4k" in t:
            return "4K"
        if "1080" in t:
            return "1080p"
        if "720" in t:
            return "720p"
        return "SD"


# --------------------------------------------------------------------------
# Converting AIOStreams streams to Seren sources (pure functions, testable)
# --------------------------------------------------------------------------
def build_info(parsed, title, cached=False):
    info = _fallback_info(title)
    if cached:
        info.add("CACHED")
    if not parsed:
        return info
    for tag in parsed.get("visualTags") or []:
        info |= VISUAL_MAP.get(tag.upper(), set())
    for tag in parsed.get("audioTags") or []:
        mapped = AUDIO_MAP.get(tag.upper())
        if mapped:
            info.add(mapped)
    for ch in parsed.get("audioChannels") or []:
        if ch in ("2.0", "5.1", "7.1"):
            info.add(ch)
    enc = ENCODE_MAP.get((parsed.get("encode") or "").upper())
    if enc:
        info.add(enc)
    info |= QUALITY_MAP.get((parsed.get("quality") or "").upper(), set())
    languages = [l for l in (parsed.get("languages") or []) if l.lower() not in ("unknown", "multi")]
    if len(languages) > 2 or any(l.lower() == "multi" for l in parsed.get("languages") or []):
        info.add("MULTI-AUDIO")
    elif len(languages) == 2:
        info.add("DUAL-AUDIO")
    if parsed.get("dubbed"):
        info.add("DUB")
    if len(parsed.get("subtitles") or []) > 1:
        info.add("MULTI-SUB")
    # Seren's rules: DV + HDR = HYBRID, DD+ beats DD
    if "DV" in info and "HDR" in info:
        info.add("HYBRID")
    if "DD+" in info:
        info.discard("DD")
    if "SDR" in info and ("HDR" in info or "DV" in info):
        info.discard("SDR")
    return info


# Property names the Lucent Seren theme reads (ListItem.Property(<name>)).
# The value is the text the theme shows; a property is left out when it
# doesn't apply. Order here is also the order of the tags in the title.
TAG_PROPERTIES = ("aio_imax", "aio_fel", "aio_lang", "aio_nlsubs")


def build_tag_properties(parsed, filename):
    """Extra tags Seren can't show on its own: IMAX, FEL/P7 and languages."""
    parsed = parsed or {}
    name = filename or ""
    props = {}
    if "IMAX" in [t.upper() for t in parsed.get("visualTags") or []] or IMAX_RE.search(name):
        props["aio_imax"] = "IMAX"
    if FEL_RE.search(name):
        props["aio_fel"] = "FEL"
    elif P7_RE.search(name):
        props["aio_fel"] = "P7"
    audio = []
    for lang in parsed.get("languages") or []:
        code = LANGUAGE_CODES.get(lang.lower())
        if code and code not in audio:
            audio.append(code)
    if "NL" in audio:
        props["aio_lang"] = "NL"
    elif "MULTI" in audio:
        props["aio_lang"] = "MULTI"
    if "dutch" in [s.lower() for s in parsed.get("subtitles") or []]:
        props["aio_nlsubs"] = "NL-SUBS"
    return props


def build_tags(parsed, filename):
    """The same tags as a list, for the title."""
    props = build_tag_properties(parsed, filename)
    return [props[k] for k in TAG_PROPERTIES if k in props]


def _with_headers(url, behavior_hints):
    headers = ((behavior_hints or {}).get("proxyHeaders") or {}).get("request") or {}
    if not headers:
        return url
    return "{}|{}".format(url, urlencode(headers))


def convert_streams(streams, include_uncached=False, number_titles=True, show_tags=False):
    """Converts an AIOStreams response into Seren sources."""
    results = []
    for stream in streams or []:
        url = stream.get("url")
        data = stream.get("streamData") or {}
        stype = (data.get("type") or "").lower()
        if not url or stype in SKIP_TYPES:
            continue
        service = data.get("service") or {}
        if not include_uncached and service and service.get("cached") is False:
            continue
        hints = stream.get("behaviorHints") or {}
        parsed = data.get("parsedFile") or {}
        filename = data.get("filename") or hints.get("filename") or ""
        title = (
            filename
            or data.get("folderName")
            or (stream.get("description") or "").split("\n")[0]
            or stream.get("name")
            or "AIOStreams"
        )
        title = title.strip()
        size = data.get("size") or hints.get("videoSize")
        quality = RESOLUTION_MAP.get(parsed.get("resolution") or "") or _fallback_quality(title)

        label = "AIO"
        if service.get("id"):
            label = "AIO|{}".format(service["id"].upper())
        elif data.get("addon"):
            label = "AIO|{}".format(str(data["addon"]).upper())

        cached = bool(service) and service.get("cached") is True or stype in ("usenet", "http")
        tag_props = build_tag_properties(parsed, filename or title)
        display_title = title
        if show_tags:
            tags = [tag_props[k] for k in TAG_PROPERTIES if k in tag_props]
            if tags:
                display_title = "[{}] {}".format(" ".join(tags), title)

        source = {
            "url": _with_headers(url, hints),
            "release_title": display_title,
            "quality": quality,
            "info": build_info(parsed, title, cached=cached),
            "provider_name_override": label,
        }
        source.update(tag_props)  # Seren turns every key into a ListItem property
        if isinstance(size, (int, float)) and size > 0:
            source["size"] = int(size / 1024 / 1024)  # Seren counts in MB
        results.append(source)

    if number_titles and results:
        width = max(2, len(str(len(results))))
        for i, source in enumerate(results, 1):
            source["release_title"] = "{}. {}".format(str(i).zfill(width), source["release_title"])
    return results


# --------------------------------------------------------------------------
# Short-lived result cache (stored in Kodi's temp folder)
# --------------------------------------------------------------------------
class ResultCache(object):
    MAX_FILES = 200

    def __init__(self, base_url, minutes):
        self.ttl = max(0, int(minutes)) * 60
        self.dir = _cache_dir() if self.ttl else None
        # Key depends on the manifest too, so a new manifest never reuses old links.
        self.salt = hashlib.sha1(base_url.encode("utf-8")).hexdigest()

    def _path(self, key):
        name = hashlib.sha1("{}|{}".format(self.salt, key).encode("utf-8")).hexdigest()
        return os.path.join(self.dir, name + ".json")

    def get(self, key):
        if not self.dir:
            return None
        path = self._path(key)
        try:
            if time.time() - os.path.getmtime(path) > self.ttl:
                os.remove(path)
                return None
            with open(path, "r") as f:
                return json.load(f)
        except (OSError, IOError, ValueError):
            return None

    def set(self, key, streams):
        if not self.dir:
            return
        try:
            with open(self._path(key), "w") as f:
                json.dump(streams, f)
            self._cleanup()
        except (OSError, IOError, TypeError, ValueError):
            pass

    def _cleanup(self):
        try:
            now = time.time()
            files = [os.path.join(self.dir, n) for n in os.listdir(self.dir) if n.endswith(".json")]
            for path in files:
                if now - os.path.getmtime(path) > self.ttl:
                    os.remove(path)
            files = sorted(
                (p for p in files if os.path.exists(p)), key=os.path.getmtime, reverse=True
            )
            for path in files[self.MAX_FILES:]:
                os.remove(path)
        except OSError:
            pass


def clear_cache():
    path = _cache_dir()
    if not path:
        return 0
    removed = 0
    for name in os.listdir(path):
        if name.endswith(".json"):
            try:
                os.remove(os.path.join(path, name))
                removed += 1
            except OSError:
                pass
    return removed


# --------------------------------------------------------------------------
# The scraper
# --------------------------------------------------------------------------
class AIOStreamsScraper(object):
    def __init__(self):
        self.base_url = base_url_from_manifest(_setting("manifest_url", ""))
        self.include_uncached = bool(_setting("include_uncached", False))
        self.number_titles = bool(_setting("keep_order", True))
        self.show_tags = bool(_setting("show_tags", False))
        self.timeout = _int_setting("timeout", 30, minimum=5)
        self.cache = ResultCache(self.base_url, _int_setting("cache_minutes", 10))

    def _request(self, media_type, stremio_id):
        url = "{}/stream/{}/{}.json".format(self.base_url, media_type, quote(stremio_id, safe=":"))
        resp = requests.get(url, headers={"User-Agent": USER_AGENT}, timeout=self.timeout)
        resp.raise_for_status()
        return resp.json().get("streams", [])

    def _fetch(self, media_type, stremio_id):
        if not self.base_url:
            _log("No manifest URL set. Enter it in the package settings.", "warning")
            return []
        key = "{}/{}".format(media_type, stremio_id)
        streams = self.cache.get(key)
        from_cache = streams is not None
        if not from_cache:
            try:
                streams = self._request(media_type, stremio_id)
            except Exception as e:  # network/JSON errors must not crash Seren
                # Never log str(e): requests puts the full URL (with the
                # encrypted AIOStreams config / debrid keys) in its messages.
                _log("Request failed for {}: {}".format(stremio_id, _safe_error(e)), "error")
                return []
            if streams:
                self.cache.set(key, streams)
        results = convert_streams(streams, self.include_uncached, self.number_titles, self.show_tags)
        _log(
            "{} sources found for {}{}".format(len(results), stremio_id, " (cached)" if from_cache else "")
        )
        return results

    def movie(self, imdb=None, tmdb=None):
        if imdb:
            return self._fetch("movie", imdb)
        if tmdb:
            return self._fetch("movie", "tmdb:{}".format(tmdb))
        return []

    def episode(self, imdb=None, tmdb=None, season=None, episode=None):
        if not season or not episode:
            return []
        if imdb:
            return self._fetch("series", "{}:{}:{}".format(imdb, season, episode))
        if tmdb:
            return self._fetch("series", "tmdb:{}:{}:{}".format(tmdb, season, episode))
        return []


# --------------------------------------------------------------------------
# Buttons in the package settings (called by Seren with setting=...)
# --------------------------------------------------------------------------
def check_connection(base_url, timeout=20):
    """Returns (ok, message). The message never contains the URL."""
    if not base_url:
        return False, "No manifest URL set. Enter your AIOStreams manifest URL first."
    try:
        resp = requests.get(
            base_url + "/manifest.json", headers={"User-Agent": USER_AGENT}, timeout=timeout
        )
        resp.raise_for_status()
        manifest = resp.json()
    except ValueError:
        return False, "The URL answered, but not with an AIOStreams manifest. Check the URL."
    except Exception as e:
        return False, "Could not reach AIOStreams: {}".format(_safe_error(e))
    if "stream" not in json.dumps(manifest.get("resources", [])):
        return False, "Reached the add-on, but it offers no streams. Is this your AIOStreams manifest?"
    name = manifest.get("name") or "AIOStreams"
    try:
        resp = requests.get(
            "{}/stream/movie/{}.json".format(base_url, TEST_IMDB_ID),
            headers={"User-Agent": USER_AGENT},
            timeout=timeout,
        )
        resp.raise_for_status()
        count = len(convert_streams(resp.json().get("streams", []), include_uncached=True))
    except Exception as e:
        return False, "Connected to {}, but the test search failed: {}".format(name, _safe_error(e))
    return True, "Connected to {}.\nTest search (The Shawshank Redemption): {} playable streams.".format(
        name, count
    )


def test_connection(*args, **kwargs):
    ok, message = check_connection(
        base_url_from_manifest(_setting("manifest_url", "")), _int_setting("timeout", 30, 5)
    )
    _log("Connection test: {}".format("OK" if ok else "failed"))
    try:
        import xbmcgui

        xbmcgui.Dialog().ok("AIOStreams", message)
    except Exception:
        pass
    return None  # keep the button's text unchanged


def clear_cache_action(*args, **kwargs):
    removed = clear_cache()
    try:
        import xbmcgui

        xbmcgui.Dialog().notification("AIOStreams", "Cache cleared ({} items)".format(removed))
    except Exception:
        pass
    return None
